import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";
import {
  buildCity, routeOptions, nodeXY, signalName, signalCode, edgeKey, speedFor, fmt,
  DEPOTS, HOSPITALS, trafficLevel, TRAFFIC_LOADS, availability, type TrafficLevel, EDGE_M, SIGNAL_WAIT_S, COLS, ROWS, scoreHospital, type Severity,
} from "@/lib/sim";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Meridian ATC — Ambulance Signal Prioritization" },
      { name: "description", content: "Traffic authority dashboard that routes ambulances and pre-empts traffic signals along the way, with live simulation." },
      { property: "og:title", content: "Meridian ATC — Ambulance Signal Prioritization" },
      { property: "og:description", content: "Register an ambulance, pick a hospital, and watch signals turn green ahead of it in real time." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Dashboard,
});

type Phase = "setup" | "running" | "paused" | "arrived";
type Status = "WAITING" | "APPROACH" | "ACTIVE" | "CLEARED" | "RED" | "GREEN";
type LogItem = { t: number; msg: string; tone: "glow" | "warn" | "go" | "dim" | "danger" };

const TIME_SCALE = 6; // sim seconds per real second at 1x

function Dashboard() {
  const [load, setLoad] = useState(1);
  const [full, setFull] = useState(false);
  useEffect(() => {
    const k = (e: KeyboardEvent) => e.key === "Escape" && setFull(false);
    window.addEventListener("keydown", k);
    return () => window.removeEventListener("keydown", k);
  }, []);
  const [filter, setFilter] = useState<TrafficLevel | "all">("all");
  const city = useMemo(() => buildCity(42, TRAFFIC_LOADS[load].load), [load]);
  const [unitId, setUnitId] = useState("AMB-0417");
  const [driver, setDriver] = useState("R. Okafor");
  const [sev, setSev] = useState<Severity>(1);
  const [depot, setDepot] = useState(0);
  const [hospital, setHospital] = useState<number | null>(null);
  const [routeId, setRouteId] = useState<string | null>(null);
  const [priorityOn, setPriorityOn] = useState(true);
  const [mult, setMult] = useState(2);
  const [phase, setPhase] = useState<Phase>("setup");
  const [error, setError] = useState("");
  const [clock, setClock] = useState("");
  const [, force] = useState(0);
  const sim = useRef({ s: 0, t: 0, wait: 0, speed: 0 });
  const prevStatus = useRef<Status[]>([]);
  const [log, setLog] = useState<LogItem[]>([]);

  const start = DEPOTS[depot].node;
  const hospitalScores = useMemo(
    () => HOSPITALS.map((h) => scoreHospital(city, start, h, sev)),
    [city, start, sev],
  );
  const aiHospital = hospitalScores.reduce((b, h, i, a) => (h.score < a[b].score ? i : b), 0);
  const hIdx = hospital ?? aiHospital;
  const options = useMemo(() => routeOptions(city, start, HOSPITALS[hIdx].node), [city, start, hIdx]);
  const route = options.find((o) => o.id === routeId) ?? options.find((o) => o.recommended) ?? options[0];
  const trafficCounts = useMemo(() => {
    const c = { low: 0, moderate: 0, high: 0 };
    for (const e of city.edges.values()) c[trafficLevel(e.density)]++;
    return c;
  }, [city]);
  const path = route.path;
  const signalIdx = path.slice(1, -1).map((_, i) => i + 1);

  useEffect(() => {
    const tick = () => setClock(new Date().toISOString().slice(11, 19) + " UTC");
    tick();
    const i = setInterval(tick, 1000);
    return () => clearInterval(i);
  }, []);

  const isRed = (node: number, t: number) => (t + city.offsets[node]) % 60 >= 28;

  const statusOf = (k: number, s: number, t: number, prio: boolean): Status => {
    const d = k - s;
    if (d <= -0.06) return "CLEARED";
    if (!prio) return isRed(path[k], t) ? "RED" : "GREEN";
    if (d < 0.35) return "ACTIVE";
    if (d < 1.6) return "APPROACH";
    return "WAITING";
  };

  const push = (items: LogItem[]) => setLog((l) => [...items.reverse(), ...l].slice(0, 40));

  // simulation loop
  useEffect(() => {
    if (phase !== "running") return;
    let raf = 0;
    let last = performance.now();
    const loop = (now: number) => {
      const dt = Math.min(0.05, (now - last) / 1000) * mult * TIME_SCALE;
      last = now;
      const st = sim.current;
      const seg = Math.min(path.length - 2, Math.floor(st.s));
      const e = city.edges.get(edgeKey(path[seg], path[seg + 1]))!;
      let kmh = speedFor(e.density) * (sev === 1 ? 1.08 : 1);
      if (!priorityOn) {
        for (const k of signalIdx) {
          const d = k - st.s;
          if (d > 0 && d <= 0.1 && isRed(path[k], st.t)) { kmh = 0; break; }
        }
      }
      if (kmh === 0) st.wait += dt;
      st.speed = kmh;
      st.s += (kmh / 3.6 / EDGE_M) * dt;
      st.t += dt;

      const events: LogItem[] = [];
      signalIdx.forEach((k, i) => {
        const ns = statusOf(k, st.s, st.t, priorityOn);
        const ps = prevStatus.current[i];
        if (ns !== ps) {
          const n = `${signalCode(path[k])} ${signalName(path[k])}`;
          if (ns === "APPROACH") events.push({ t: st.t, msg: `${n} · ambulance approaching, pre-empt queued`, tone: "warn" });
          if (ns === "ACTIVE") events.push({ t: st.t, msg: `${n} · PRIORITY ACTIVE, cross-traffic held`, tone: "glow" });
          if (ns === "CLEARED") events.push({ t: st.t, msg: priorityOn ? `${n} · passed, priority deactivated` : `${n} · passed`, tone: "go" });
          if (ns === "RED" && ps && ps !== "WAITING" && k - st.s < 1.2) events.push({ t: st.t, msg: `${n} · RED ahead, no pre-emption`, tone: "danger" });
        }
        prevStatus.current[i] = ns;
      });

      if (st.s >= path.length - 1) {
        st.s = path.length - 1;
        events.push({ t: st.t, msg: `${unitId} arrived at ${HOSPITALS[hIdx].name} · total ${fmt(st.t)}`, tone: "go" });
        if (events.length) push(events);
        setPhase("arrived");
        force((x) => x + 1);
        return;
      }
      if (events.length) push(events);
      force((x) => x + 1);
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [phase, mult, priorityOn, path]);

  const dispatch = () => {
    if (!unitId.trim() || !driver.trim()) { setError("Unit ID and driver are required."); return; }
    setError("");
    sim.current = { s: 0, t: 0, wait: 0, speed: 0 };
    prevStatus.current = signalIdx.map(() => "WAITING" as Status);
    const h = HOSPITALS[hIdx];
    setLog([]);
    push([
      { t: 0, msg: `${unitId} registered · SEV-${sev} · driver ${driver}`, tone: "dim" },
      { t: 0, msg: `${h.name} confirmed · ${h.beds} beds free`, tone: "dim" },
      { t: 0, msg: `Route ${route.label} · ${route.km.toFixed(1)} km · ${signalIdx.length} signals identified`, tone: "glow" },
      { t: 0, msg: priorityOn ? `Priority plan pushed to ${signalIdx.length} controllers` : `Priority system OFF · baseline run`, tone: priorityOn ? "glow" : "danger" },
    ]);
    setPhase("running");
  };
  const reset = () => { sim.current = { s: 0, t: 0, wait: 0, speed: 0 }; setLog([]); setPhase("setup"); };

  const st = sim.current;
  const live = phase !== "setup";
  const statuses = signalIdx.map((k) => (live ? statusOf(k, st.s, st.t, priorityOn) : ("WAITING" as Status)));
  const passed = statuses.filter((s) => s === "CLEARED").length;
  const anyActive = statuses.includes("ACTIVE");

  // remaining ETA
  let remaining = 0;
  for (let i = Math.floor(st.s); i < path.length - 1; i++) {
    const e = city.edges.get(edgeKey(path[i], path[i + 1]))!;
    const frac = i === Math.floor(st.s) ? 1 - (st.s - i) : 1;
    remaining += (frac * EDGE_M) / (speedFor(e.density) / 3.6);
  }
  if (!priorityOn) remaining += (signalIdx.length - passed) * SIGNAL_WAIT_S * 0.6;
  const eta = live ? remaining : route.etaPriority;

  // ambulance position
  const seg = Math.min(path.length - 2, Math.floor(st.s));
  const a = nodeXY(path[seg]), b = nodeXY(path[seg + 1] ?? path[seg]);
  const f = st.s - seg;
  const amb = { x: a.x + (b.x - a.x) * f, y: a.y + (b.y - a.y) * f };

  const steps = ["Register", "Destination", "Route", "Signals", "Priority", "En route", "Hospital"];
  const stepIdx = phase === "setup" ? 3 : phase === "arrived" ? 6 : anyActive ? 4 : 5;

  return (
    <div className="min-h-screen w-full bg-bg text-text antialiased">
      <header className="sticky top-0 z-30 border-b border-line/70 bg-panel/70 backdrop-blur-xl">
        <div className="flex items-center gap-4 px-5 py-3">
          <div className="flex items-center gap-2.5">
            <div className="grid size-8 place-items-center rounded-lg bg-glow/15 font-bold text-glow ring-1 ring-glow/40">◆</div>
            <div className="leading-tight">
              <h1 className="text-[13px] font-semibold tracking-tight">MERIDIAN ATC</h1>
              <div className="label-mono">Ambulance Signal Priority · Grid 04</div>
            </div>
          </div>
          <ol className="ml-6 hidden items-center gap-1 font-mono text-[10px] xl:flex">
            {steps.map((s, i) => (
              <li key={s} className={`rounded-full px-2 py-1 ring-1 ${i < stepIdx ? "text-go ring-go/30" : i === stepIdx ? "bg-glow/15 text-glow ring-glow/40" : "text-dim ring-line"}`}>
                {i + 1}. {s}
              </li>
            ))}
          </ol>
          <div className="ml-auto flex items-center gap-2 font-mono text-[11px]">
            <span className={`flex items-center gap-1.5 rounded-full px-2.5 py-1 ring-1 ${phase === "running" ? "bg-go/10 text-go ring-go/30" : "text-dim ring-line"}`}>
              <i className={`size-1.5 rounded-full ${phase === "running" ? "animate-pulse bg-go" : "bg-dim"}`} />
              {phase === "running" ? "LIVE" : phase.toUpperCase()}
            </span>
            <span className="rounded-full bg-panel px-2.5 py-1 text-dim ring-1 ring-line">{clock}</span>
            <span className={`rounded-full px-2.5 py-1 ring-1 ${sev === 1 ? "bg-warn/10 text-warn ring-warn/30" : "text-dim ring-line"}`}>SEV-{sev}</span>
          </div>
        </div>
      </header>

      <div className="grid grid-cols-1 gap-3 p-3 lg:grid-cols-[290px_1fr_340px]">
        {/* LEFT */}
        <aside className="space-y-3">
          <section className="glass p-4">
            <div className="label-mono mb-3">1 · Unit Registration</div>
            <div className="space-y-2.5">
              <Field label="Unit ID" value={unitId} onChange={setUnitId} disabled={live} />
              <Field label="Driver" value={driver} onChange={setDriver} disabled={live} />
              <div>
                <span className="text-[11px] text-dim">Emergency severity</span>
                <div className="mt-1 flex gap-1.5">
                  {([1, 2, 3] as Severity[]).map((s) => (
                    <button key={s} disabled={live} onClick={() => setSev(s)}
                      className={`flex-1 rounded-lg px-2 py-2 text-center text-[11px] ring-1 transition ${sev === s ? "bg-warn/15 text-warn ring-warn/40" : "text-dim ring-line hover:text-text"}`}>
                      SEV-{s}
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <span className="text-[11px] text-dim">Start location</span>
                <select disabled={live} value={depot} onChange={(e) => { setDepot(+e.target.value); setHospital(null); }}
                  className="mt-1 w-full rounded-lg bg-bg/60 px-3 py-2 text-[13px] ring-1 ring-line outline-none">
                  {DEPOTS.map((d, i) => <option key={d.name} value={i}>{d.name}</option>)}
                </select>
              </div>
            </div>
          </section>

          <section className="glass p-4">
            <div className="label-mono mb-3">2 · Destination · Availability</div>
            <div className="space-y-2">
              {HOSPITALS.map((h, i) => (
                <button key={h.name} disabled={live} onClick={() => setHospital(i)}
                  className={`w-full rounded-xl p-3 text-left ring-1 transition ${hIdx === i ? "bg-glow/10 ring-glow/40" : "ring-line hover:ring-dim"}`}>
                  <div className="flex items-center justify-between">
                    <span className={`text-[13px] ${hIdx === i ? "font-semibold" : "text-dim"}`}>{h.name}</span>
                    {i === aiHospital && <span className="rounded bg-glow/15 px-1.5 font-mono text-[9px] text-glow">AI PICK</span>}
                  </div>
                  <div className="mt-0.5 font-mono text-[11px] text-dim">
                    <span className={h.beds ? "text-go" : "text-danger"}>{h.beds ? `${h.beds}/${h.total} beds free` : "Beds full"}</span>
                    {" · ICU "}{h.icu}{" · ER "}{h.erWait}m
                  </div>
                  <div className="mt-1.5 h-1 overflow-hidden rounded-full bg-line">
                    <div className={availability(h) === "full" ? "h-1 bg-danger" : availability(h) === "limited" ? "h-1 bg-warn" : "h-1 bg-go"} style={{ width: `${((h.total - h.beds) / h.total) * 100}%` }} />
                  </div>
                  <div className="mt-1 font-mono text-[10px] text-dim">
                    {Math.round(((h.total - h.beds) / h.total) * 100)}% occupied · {h.trauma ? "trauma bay" : "no trauma"} · ETA {fmt(hospitalScores[i].eta)}
                  </div>
                </button>
              ))}
            </div>
          </section>

          <section className="glass p-4">
            <div className="mb-3 flex items-center justify-between">
              <div className="label-mono">3 · Route Suggester</div>
              {routeId && !live && (
                <button onClick={() => setRouteId(null)} className="font-mono text-[10px] text-glow hover:underline">use suggested</button>
              )}
            </div>
            <div className="space-y-2">
              {[...options].sort((x, y) => x.score - y.score).map((o, rank) => (
                <button key={o.id} disabled={live} onClick={() => setRouteId(o.id)}
                  className={`w-full rounded-xl p-3 text-left ring-1 transition ${route.id === o.id ? "bg-bg/60 ring-glow/40" : "ring-line hover:ring-dim"}`}>
                  <div className="flex items-center justify-between text-[12px]">
                    <span className="flex items-center gap-1.5">
                      <span className="font-mono text-[10px] text-dim">#{rank + 1}</span>
                      {o.label}
                    </span>
                    <span className="font-mono text-go">ETA {fmt(o.etaPriority)}</span>
                  </div>
                  {o.recommended && (
                    <div className="mt-1 inline-block rounded bg-glow/15 px-1.5 font-mono text-[9px] text-glow">SUGGESTED FOR AMBULANCE</div>
                  )}
                  <div className="mt-1.5 flex h-1.5 overflow-hidden rounded-full bg-line">
                    <div className="bg-go" style={{ flex: o.traffic.low }} />
                    <div className="bg-warn" style={{ flex: o.traffic.moderate }} />
                    <div className="bg-danger" style={{ flex: o.traffic.high }} />
                  </div>
                  <div className="mt-1 flex gap-2 font-mono text-[10px]">
                    <span className="text-go">{o.traffic.low} low</span>
                    <span className="text-warn">{o.traffic.moderate} mod</span>
                    <span className="text-danger">{o.traffic.high} high</span>
                    <span className="ml-auto text-dim">{o.km.toFixed(1)} km · {o.path.length - 2} sig</span>
                  </div>
                  {o.reasons.length > 0 && <div className="mt-1 text-[10px] text-dim">{o.reasons.join(" · ")}</div>}
                </button>
              ))}
            </div>
          </section>
        </aside>

        {/* CENTER */}
        <main className="glass p-4">
          <div className={full ? "fixed inset-0 z-50 overflow-hidden map-grid" : "relative overflow-hidden rounded-xl ring-1 ring-line map-grid"}>
            <svg viewBox="0 0 1000 620" className={full ? "block h-full w-full pt-12 pb-20" : "block h-auto w-full"}>
              {[...city.edges.values()].map((e) => {
                const p = nodeXY(e.a), q = nodeXY(e.b);
                const lvl = trafficLevel(e.density);
                const c = lvl === "high" ? "var(--danger)" : lvl === "moderate" ? "var(--warn)" : "var(--go)";
                const on = filter === "all" || filter === lvl;
                return <line key={edgeKey(e.a, e.b)} x1={p.x} y1={p.y} x2={q.x} y2={q.y} stroke={on ? c : "var(--line)"} strokeOpacity={on ? (filter === "all" ? 0.25 + e.density * 0.3 : 0.85) : 0.25} strokeWidth={filter === lvl ? 8 : 6} strokeLinecap="round" />;
              })}
              {Array.from({ length: COLS * ROWS }, (_, id) => {
                const p = nodeXY(id);
                return <circle key={id} cx={p.x} cy={p.y} r={2.5} fill="var(--dim)" opacity={0.5} />;
              })}
              {!live && options.filter((o) => o.id !== route.id).map((o) => (
                <polyline key={o.id} points={o.path.map((n) => { const p = nodeXY(n); return `${p.x},${p.y}`; }).join(" ")}
                  fill="none" stroke="var(--text)" strokeOpacity={0.35} strokeWidth={2} strokeDasharray="4 6" strokeLinejoin="round" />
              ))}
              <polyline points={path.map((n) => { const p = nodeXY(n); return `${p.x},${p.y}`; }).join(" ")}
                fill="none" stroke="var(--glow)" strokeOpacity={0.25} strokeWidth={14} strokeLinejoin="round" strokeLinecap="round" />
              <polyline className="route-dash" points={path.map((n) => { const p = nodeXY(n); return `${p.x},${p.y}`; }).join(" ")}
                fill="none" stroke="var(--glow)" strokeWidth={3} strokeDasharray="14 6" strokeLinejoin="round" />

              {signalIdx.map((k, i) => {
                const p = nodeXY(path[k]);
                const s = statuses[i];
                const fill = s === "ACTIVE" || s === "GREEN" ? "var(--go)" : s === "APPROACH" ? "var(--warn)" : s === "CLEARED" ? "var(--dim)" : s === "RED" ? "var(--danger)" : "var(--line)";
                return (
                  <g key={k}>
                    {s === "ACTIVE" && <circle cx={p.x} cy={p.y} r={8} fill="none" stroke="var(--go)" strokeWidth={2} className="ping-ring" />}
                    <circle cx={p.x} cy={p.y} r={8} fill={fill} stroke="var(--bg)" strokeWidth={3} />
                    <text x={p.x + 12} y={p.y - 10} fontSize={11} fill="var(--dim)" fontFamily="var(--font-mono)">{signalCode(path[k])}</text>
                  </g>
                );
              })}

              {DEPOTS.map((d) => { const p = nodeXY(d.node); return <rect key={d.name} x={p.x - 7} y={p.y - 7} width={14} height={14} rx={3} fill={d.node === start ? "var(--go)" : "var(--line)"} />; })}
              {HOSPITALS.map((h, i) => {
                const p = nodeXY(h.node);
                const av = availability(h);
                const tone = av === "full" ? "var(--danger)" : av === "limited" ? "var(--warn)" : "var(--go)";
                const sel = i === hIdx;
                const occ = (h.total - h.beds) / h.total;
                const cx = p.x + h.lx, cy = p.y + h.ly;
                return (
                  <g key={h.name} className={live ? "" : "cursor-pointer"} onClick={() => !live && setHospital(i)}>
                    <title>{`${h.name} — ${h.beds}/${h.total} beds free, ICU ${h.icu}, ER wait ${h.erWait} min`}</title>
                    <line x1={p.x} y1={p.y} x2={cx + (h.lx < 0 ? 158 : 0)} y2={cy} stroke={sel ? "var(--glow)" : "var(--line)"} strokeWidth={1} />
                    <rect x={cx} y={cy} width={158} height={62} rx={8} fill="var(--panel)" fillOpacity={0.94} stroke={sel ? "var(--glow)" : tone} strokeOpacity={sel ? 1 : 0.5} strokeWidth={sel ? 2 : 1} />
                    <text x={cx + 10} y={cy + 17} fontSize={12} fontWeight={600} fill="var(--text)">{h.name}</text>
                    <circle cx={cx + 146} cy={cy + 13} r={4} fill={tone} />
                    <text x={cx + 10} y={cy + 33} fontSize={10} fill={tone} fontFamily="var(--font-mono)">
                      {av === "full" ? "FULL" : `${h.beds}/${h.total} BEDS`}
                    </text>
                    <text x={cx + 148} y={cy + 33} textAnchor="end" fontSize={10} fill="var(--dim)" fontFamily="var(--font-mono)">ICU {h.icu} · ER {h.erWait}m</text>
                    <rect x={cx + 10} y={cy + 42} width={138} height={5} rx={2.5} fill="var(--line)" />
                    <rect x={cx + 10} y={cy + 42} width={138 * occ} height={5} rx={2.5} fill={tone} />
                    <text x={cx + 10} y={cy + 57} fontSize={8} fill="var(--dim)" fontFamily="var(--font-mono)">
                      {Math.round(occ * 100)}% OCCUPIED{i === aiHospital ? " · AI PICK" : ""}{sel ? " · SELECTED" : ""}
                    </text>
                    <rect x={p.x - 12} y={p.y - 12} width={24} height={24} rx={6} fill={sel ? "var(--glow)" : tone} />
                    <text x={p.x} y={p.y + 5} textAnchor="middle" fontSize={14} fontWeight={700} fill="var(--bg)">H</text>
                  </g>
                );
              })}

              <g transform={`translate(${amb.x},${amb.y})`}>
                {phase === "running" && <circle r={8} fill="none" stroke="var(--glow)" strokeWidth={2} className="ping-ring" />}
                <circle r={10} fill="var(--glow)" stroke="var(--bg)" strokeWidth={3} />
                <text y={4} textAnchor="middle" fontSize={11} fontWeight={700} fill="var(--bg)">+</text>
              </g>
            </svg>
            <div className="absolute left-3 top-3 flex flex-wrap items-center gap-1 rounded-lg bg-panel/85 p-1 font-mono text-[10px] ring-1 ring-line backdrop-blur">
              {([["all", "All traffic", "text-text"], ["low", `Low · ${trafficCounts.low}`, "text-go"], ["moderate", `Moderate · ${trafficCounts.moderate}`, "text-warn"], ["high", `High · ${trafficCounts.high}`, "text-danger"]] as const).map(([id, label, tone]) => (
                <button key={id} onClick={() => setFilter(id)}
                  className={`rounded-md px-2 py-1 ${tone} ${filter === id ? "bg-bg ring-1 ring-line" : "opacity-70 hover:opacity-100"}`}>
                  {id !== "all" && "■ "}{label}
                </button>
              ))}
            </div>
            <div className="absolute right-3 top-3 flex items-center gap-1 rounded-lg bg-panel/85 p-1 font-mono text-[10px] ring-1 ring-line backdrop-blur">
              <span className="px-1.5 text-dim">Traffic</span>
              {TRAFFIC_LOADS.map((t, i) => (
                <button key={t.id} disabled={live} onClick={() => { setLoad(i); setRouteId(null); }}
                  className={`rounded-md px-2 py-1 ${load === i ? "bg-bg text-glow ring-1 ring-line" : "text-dim hover:text-text"} disabled:opacity-50`}>
                  {t.label}
                </button>
              ))}
            </div>
            <button onClick={() => setFull((f) => !f)} aria-label={full ? "Exit full screen" : "Full screen map"}
              className="absolute bottom-3 right-3 rounded-lg bg-panel/85 px-3 py-1.5 font-mono text-[11px] text-glow ring-1 ring-glow/40 backdrop-blur hover:bg-glow/15">
              {full ? "✕ Exit full screen" : "⤢ Full screen"}
            </button>
            {full && (
              <div className="absolute bottom-3 left-3 flex items-center gap-4 rounded-lg bg-panel/85 px-4 py-2 font-mono text-[12px] ring-1 ring-line backdrop-blur">
                <span className="text-dim">ETA <b className="text-text">{fmt(eta)}</b></span>
                <span className="text-dim">SPEED <b className="text-text">{Math.round(live ? st.speed : 0)} km/h</b></span>
                <span className="text-dim">SIGNALS <b className="text-text">{passed}/{signalIdx.length}</b></span>
                <span className="text-dim">DEST <b className="text-glow">{HOSPITALS[hIdx].name}</b></span>
                {phase === "setup" && <button onClick={dispatch} className="rounded-md bg-glow/15 px-3 py-1 text-glow ring-1 ring-glow/40">▶ Dispatch</button>}
                {phase === "running" && <button onClick={() => setPhase("paused")} className="rounded-md px-3 py-1 text-text ring-1 ring-line">⏸ Pause</button>}
                {phase === "paused" && <button onClick={() => setPhase("running")} className="rounded-md bg-glow/15 px-3 py-1 text-glow ring-1 ring-glow/40">▶ Resume</button>}
              </div>
            )}
          </div>

          <div className="mt-4 grid grid-cols-2 gap-2 text-center sm:grid-cols-4">
            <Stat label="ETA" value={fmt(eta)} />
            <Stat label="Speed" value={`${Math.round(live ? st.speed : 0)}`} unit=" km/h" />
            <Stat label="Priority" value={!priorityOn ? "OFF" : anyActive ? "ACTIVE" : live ? "ARMED" : "READY"}
              tone={!priorityOn ? "text-danger" : anyActive ? "text-warn" : "text-glow"} />
            <Stat label="Signals" value={`${passed}/${signalIdx.length}`} />
          </div>

          {phase === "arrived" && (
            <div className="mt-3 rounded-xl bg-go/10 p-3 text-[13px] ring-1 ring-go/30 animate-fade-in">
              Arrived at <b>{HOSPITALS[hIdx].name}</b> in <span className="font-mono">{fmt(st.t)}</span>.{" "}
              {priorityOn
                ? <>Estimated without priority: <span className="font-mono">{fmt(route.etaNormal)}</span> — saved <span className="font-mono text-go">{fmt(route.etaNormal - st.t)}</span>.</>
                : <>Waited <span className="font-mono text-danger">{fmt(st.wait)}</span> at red lights. Turn priority on and run again to compare.</>}
            </div>
          )}
        </main>

        {/* RIGHT */}
        <aside className="space-y-3">
          <section className="glass p-4">
            <div className="mb-3 flex items-center justify-between">
              <div className="label-mono">4 · Signal Rail</div>
              <div className="font-mono text-[10px] text-dim">{signalIdx.length} nodes</div>
            </div>
            <div className="max-h-[340px] space-y-1.5 overflow-y-auto pr-1">
              {signalIdx.map((k, i) => <SignalRow key={k} node={path[k]} status={statuses[i]} />)}
            </div>
          </section>

          <section className="glass p-4">
            <div className="label-mono mb-3">Event Log</div>
            <div className="max-h-[220px] space-y-1.5 overflow-y-auto font-mono text-[11px] text-dim">
              {log.length === 0 && <div>Awaiting dispatch…</div>}
              {log.map((l, i) => (
                <div key={i} className="animate-fade-in">
                  <span className="text-glow">T+{fmt(l.t)}</span> ·{" "}
                  <span className={l.tone === "warn" ? "text-warn" : l.tone === "go" ? "text-go" : l.tone === "danger" ? "text-danger" : l.tone === "glow" ? "text-text" : ""}>{l.msg}</span>
                </div>
              ))}
            </div>
          </section>

          <section className="glass space-y-2 p-3">
            <div className="flex items-center justify-between px-1 text-[12px]">
              <span className="text-dim">Signal priority system</span>
              <button disabled={phase === "running"} onClick={() => setPriorityOn((p) => !p)}
                className={`rounded-full px-3 py-1 font-mono text-[11px] ring-1 ${priorityOn ? "bg-go/10 text-go ring-go/30" : "bg-danger/10 text-danger ring-danger/30"}`}>
                {priorityOn ? "ON" : "OFF"}
              </button>
            </div>
            {error && <div className="px-1 text-[11px] text-danger">{error}</div>}
            <div className="flex items-center gap-2">
              {phase === "setup" && (
                <button onClick={dispatch} className="flex-1 rounded-xl bg-glow/15 px-3 py-2.5 text-[12px] font-semibold text-glow ring-1 ring-glow/40 hover:bg-glow/25">▶ Dispatch</button>
              )}
              {phase === "running" && (
                <button onClick={() => setPhase("paused")} className="flex-1 rounded-xl px-3 py-2.5 text-[12px] text-text ring-1 ring-line">⏸ Pause</button>
              )}
              {phase === "paused" && (
                <button onClick={() => setPhase("running")} className="flex-1 rounded-xl bg-glow/15 px-3 py-2.5 text-[12px] font-semibold text-glow ring-1 ring-glow/40">▶ Resume</button>
              )}
              {phase === "arrived" && (
                <button onClick={reset} className="flex-1 rounded-xl bg-glow/15 px-3 py-2.5 text-[12px] font-semibold text-glow ring-1 ring-glow/40">↺ New dispatch</button>
              )}
              {[1, 2, 4].map((m) => (
                <button key={m} onClick={() => setMult(m)}
                  className={`rounded-xl px-3 py-2.5 font-mono text-[11px] ring-1 ${mult === m ? "text-glow ring-glow/40" : "text-dim ring-line"}`}>{m}×</button>
              ))}
              {(phase === "running" || phase === "paused") && (
                <button onClick={reset} className="rounded-xl px-3 py-2.5 text-[12px] text-dim ring-1 ring-line" aria-label="Reset">↺</button>
              )}
            </div>
          </section>
        </aside>
      </div>
    </div>
  );
}

function Field({ label, value, onChange, disabled }: { label: string; value: string; onChange: (v: string) => void; disabled?: boolean }) {
  return (
    <label className="block">
      <span className="text-[11px] text-dim">{label}</span>
      <input value={value} disabled={disabled} maxLength={24} onChange={(e) => onChange(e.target.value)}
        className="mt-1 w-full rounded-lg bg-bg/60 px-3 py-2 text-[13px] ring-1 ring-line outline-none focus:ring-glow/50 disabled:opacity-70" />
    </label>
  );
}

function Stat({ label, value, unit, tone }: { label: string; value: string; unit?: string; tone?: string }) {
  return (
    <div className="rounded-xl bg-bg/60 p-3 ring-1 ring-line">
      <div className="label-mono">{label}</div>
      <div className={`mt-1 font-mono text-xl font-semibold ${tone ?? ""}`}>{value}{unit && <span className="text-[10px] text-dim">{unit}</span>}</div>
    </div>
  );
}

const ROW_STYLE: Record<Status, { box: string; dot: string; text: string; label: string }> = {
  CLEARED: { box: "bg-go/5 ring-go/20", dot: "bg-go/60", text: "text-go", label: "CLEARED" },
  ACTIVE: { box: "bg-go/10 ring-go/40", dot: "bg-go animate-pulse", text: "text-go", label: "PRIORITY ACTIVE" },
  APPROACH: { box: "bg-warn/10 ring-warn/40", dot: "bg-warn", text: "text-warn", label: "APPROACHING" },
  WAITING: { box: "ring-line", dot: "bg-dim/60", text: "text-dim", label: "WAITING" },
  RED: { box: "bg-danger/10 ring-danger/30", dot: "bg-danger", text: "text-danger", label: "RED" },
  GREEN: { box: "ring-line", dot: "bg-go", text: "text-go", label: "GREEN" },
};

function SignalRow({ node, status }: { node: number; status: Status }) {
  const s = ROW_STYLE[status];
  return (
    <div className={`flex items-center gap-2 rounded-lg px-3 py-2 ring-1 transition-colors ${s.box}`}>
      <span className={`size-2 rounded-full ${s.dot}`} />
      <span className={`text-[12px] ${status === "WAITING" ? "text-dim" : ""}`}>{signalCode(node)} · {signalName(node)}</span>
      <span className={`ml-auto font-mono text-[10px] ${s.text}`}>{s.label}</span>
    </div>
  );
}
